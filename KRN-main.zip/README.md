# KRN

python:3.8.8

pip install PyAudio  
pip install certifi
pip install requirements.txt  
sudo apt-get install ffmpeg  
