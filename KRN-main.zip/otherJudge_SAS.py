#!/usr/bin/env python
# coding: utf-8

# In[14]:


# FILENAME:otherJudge_SAS.py

import tkinter
from tkinter import *
from tkinter import ttk
import pandas as pd
##import pymysql
from PIL import Image, ImageTk
import time
import otherJudge as otherJudge
from aiJudge import aiJudge as aj
from scaleDegree import otherSASFunc


# 返回otherJudge
def back2otherJudge():
    selfSAS.destroy()
    otherJudge.otherJudge()

# 插入数据库
def insert(patientid, age, testScore, answer):
    global testType
    testType = 'otherSAS'
    # 时间戳
    now = int(round(time.time() * 1000))
    currentTime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(now/1000))
    # 入库
    connection = pymysql.connect(host='127.0.0.1', port=3306, user='root', passwd='root', db='krndb', charset='utf8')
    cursor = connection.cursor()
    cursor.execute("insert into score (patientId, age, testType, testScore, answer, insertTime) values (%s, %s, %s, %s, %s, %s)", (patientid, age, testType, testScore, str(answer), currentTime))
    connection.commit()
    connection.close()
    cursor.close()


def getOtherSASData():
    id = entry_Id.get()
    age = entry_Age.get()
    testType = "otherSAS"

    if v1.get() == 0:
        tkinter.messagebox.showinfo("提示", "第1题选项不能为空！")
    elif v2.get() == 0:
        tkinter.messagebox.showinfo("提示", "第2题选项不能为空！")
    elif v3.get() == 0:
        tkinter.messagebox.showinfo("提示", "第3题选项不能为空！")
    elif v4.get() == 0:
        tkinter.messagebox.showinfo("提示", "第4题选项不能为空！")
    elif v5.get() == 0:
        tkinter.messagebox.showinfo("提示", "第5题选项不能为空！")
    elif v6.get() == 0:
        tkinter.messagebox.showinfo("提示", "第6题选项不能为空！")
    elif v7.get() == 0:
        tkinter.messagebox.showinfo("提示", "第7题选项不能为空！")
    elif v8.get() == 0:
        tkinter.messagebox.showinfo("提示", "第8题选项不能为空！")
    elif v9.get() == 0:
        tkinter.messagebox.showinfo("提示", "第9题选项不能为空！")
    elif v10.get() == 0:
        tkinter.messagebox.showinfo("提示", "第10题选项不能为空！")
    elif v11.get() == 0:
        tkinter.messagebox.showinfo("提示", "第11题选项不能为空！")
    elif v12.get() == 0:
        tkinter.messagebox.showinfo("提示", "第12题选项不能为空！")
    elif v13.get() == 0:
        tkinter.messagebox.showinfo("提示", "第13题选项不能为空！")
    elif v14.get() == 0:
        tkinter.messagebox.showinfo("提示", "第14题选项不能为空！")

    elif id == '' or age == '':
        tkinter.messagebox.showinfo('提示', '请输入编号或者年龄')
    else:
        global _sasScore
        global answerList
        answerList = []


        answerList.append(optionList[v1.get()-1][0])
        answerList.append(optionList[v2.get()-1][0])
        answerList.append(optionList[v3.get()-1][0])
        answerList.append(optionList[v4.get()-1][0])
        answerList.append(optionList[v5.get()-1][0])
        answerList.append(optionList[v6.get()-1][0])
        answerList.append(optionList[v7.get()-1][0])
        answerList.append(optionList[v8.get()-1][0])
        answerList.append(optionList[v9.get()-1][0])
        answerList.append(optionList[v10.get()-1][0])
        answerList.append(optionList[v11.get()-1][0])
        answerList.append(optionList[v12.get()-1][0])
        answerList.append(optionList[v13.get()-1][0])
        answerList.append(optionList[v14.get()-1][0])



        # 计算得分
        _sasScore = (v1.get() + v2.get() + v3.get() + v4.get() + v5.get() + v6.get() + v7.get() + v8.get() + v9.get() + v10.get() + v11.get() + v12.get() + v13.get() + v14.get())-14

        insert(patientid=id, age=age, testScore=_sasScore, answer=answerList)
        tkinter.messagebox.showinfo('提示', '提交成功，请进行录音检测')

        # 程度
        otherSASDegree = otherSASFunc(sc=_sasScore)
        selfSAS.destroy()
        aj(ts=_sasScore, id=id, age=age, type=testType, deg=otherSASDegree)

# 鼠标滚动
def processWheel(event):
    a= int(-(event.delta)/60)
    canvas.yview_scroll(a,'units')

def resize(w_box, h_box, pil_image):  # 参数是：要适应的窗口宽、高、Image.open后的图片
    w, h = pil_image.size  # 获取图像的原始大小
    f1 = 1.0 * w_box / w
    f2 = 1.0 * h_box / h
    factor = min([f1, f2])
    width = int(w * factor)
    height = int(h * factor)
    return pil_image.resize((width, height), Image.ANTIALIAS)

# 原click
# def click():
#     i = 0.8
#     j = 0.02
#     Label(text="题卡:", font=('black', 20), bg='white').place(width=70,height=30, relx=i,rely=j)
#     j += 0.05
#     if v1.get()==0:
#         Label(text="1.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="1.", font=('black', 20)).place(width=50,height=30,relx=i,rely=j)
#
#     i += 0.05
#     if v2.get()==0:
#         Label(text="2.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="2.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v3.get()==0:
#         Label(text="3.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="3.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v4.get()==0:
#         Label(text="4.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="4.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
# ######
#     j += 0.05
#     i = 0.8
#     if v5.get()==0:
#         Label(text="5.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="5.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v6.get()==0:
#         Label(text="6.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="6.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i+= 0.05
#     if v7.get()==0:
#         Label(text="7.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="7.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v8.get()==0:
#         Label(text="8.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="8.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#
# #####
#     i = 0.8
#     j += 0.05
#     if v9.get()==0:
#         Label(text="9.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="9.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i +=0.05
#     if v10.get()==0:
#         Label(text="10.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="10.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v11.get()==0:
#         Label(text="11.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="11.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v12.get()==0:
#         Label(text="12.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="12.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#
# #####
#     i = 0.8
#     j += 0.05
#     if v13.get()==0:
#         Label(text="13.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="13.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)
#     i += 0.05
#     if v14.get()==0:
#         Label(text="14.", font=('black', 20), bg='red').place(width=50,height=30, relx=i,rely=j)
#     else:
#         Label(text="14.", font=('black', 20)).place(width=50,height=30, relx=i,rely=j)


def click():
    fontsize = 15   # 题卡内容字号
    width = 30  # 题卡按钮宽度
    gap = 0.035  # 题卡间距

    i = 0.8
    j = 0.035
    Label(text="题卡:", font=('black', 20), bg='white').place(width=70,height=30, relx=i,rely=j)
    j += 0.05
    if v1.get()==0:
        Label(text="1.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="1.", font=('black', fontsize)).place(width=width,height=30,relx=i,rely=j)

    i += gap
    if v2.get()==0:
        Label(text="2.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="2.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v3.get()==0:
        Label(text="3.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="3.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v4.get()==0:
        Label(text="4.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="4.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)

    j += 0.05
    i = 0.8
    if v5.get()==0:
        Label(text="5.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="5.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v6.get()==0:
        Label(text="6.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="6.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i+= gap
    if v7.get()==0:
        Label(text="7.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="7.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v8.get()==0:
        Label(text="8.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="8.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)


    i = 0.8
    j += 0.05
    if v9.get()==0:
        Label(text="9.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="9.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i +=gap
    if v10.get()==0:
        Label(text="10.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="10.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v11.get()==0:
        Label(text="11.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="11.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v12.get()==0:
        Label(text="12.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="12.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)


    i = 0.8
    j += 0.05
    if v13.get()==0:
        Label(text="13.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="13.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap
    if v14.get()==0:
        Label(text="14.", font=('black', fontsize), bg='red').place(width=width,height=30, relx=i,rely=j)
    else:
        Label(text="14.", font=('black', fontsize)).place(width=width,height=30, relx=i,rely=j)
    i += gap


def otherJudgeSAS():

    global selfSAS
    selfSAS = tkinter.Tk()  # tkinter窗口

    # 获取屏幕分辨率
    screenWidth = selfSAS.winfo_screenwidth()
    screenHeight = selfSAS.winfo_screenheight()

    screenWidth = int(screenWidth)
    screenHeight = int(screenHeight)



    # 设置窗口全屏显示
    selfSAS.geometry("%sx%s" % (screenWidth, screenHeight))

    # 设置窗口宽高固定
    selfSAS.resizable(0, 0)

    selfSAS.title("汉密顿焦虑量表")
    selfSAS.configure(bg='white')

    # 焦虑自评表标题
    lbStatus = tkinter.Label(selfSAS, text='汉密顿焦虑量表', font=('black',40), fg='black', bg='white')
    lbStatus.place(relx=0.40, rely=0.005)

    # 提示信息
    Label(selfSAS, text="请选择最适合的答案:（1.没有或很少时间2.小部分时间3.相当多时间4.绝大部分或全部时间）", bg='white').place(relx=0.35, rely=0.12)

    global entry_Id
    # 患者编号
    tkinter.Label(selfSAS, text='编号：', font=('Arial', 15), fg='black', bg='white').place(relx=0.36, rely=0.08)
    entry_Id = tkinter.Entry(selfSAS, highlightcolor='red', highlightthickness=1)
    entry_Id.place(width=100, height=30, relx=0.40, rely=0.08)

    # 患者年龄
    tkinter.Label(selfSAS, text='年龄：', font=('Arial', 15), fg='black', bg='white').place(relx=0.50, rely=0.08)
    global entry_Age
    entry_Age = tkinter.Entry(selfSAS, highlightcolor='red', highlightthickness=1)
    entry_Age.place(width=100, height=30, relx=0.53, rely=0.08)

    # 提交按钮
    backBut = tkinter.Button(selfSAS, text='提交', font=('Arial', 15), width=10, height=2, bg='white',
                   fg='black',relief=RIDGE, borderwidth=1, command=getOtherSASData)
    backBut.place(relx=0.45, rely=0.85, relwidth=0.07, relheight=0.07)

    # 返回otherJudge按钮
    tkinter.Button(selfSAS, text='<返回“他评量表选择”', font=('Arial', 15), width=12, height=2, bg='white',
                   fg='black',relief=RIDGE, command=back2otherJudge,
                   borderwidth=1).place(relx=0.05, rely=0.05, relwidth=0.10, relheight=0.05)



    textList = []  # 存储题库题目
    df = pd.read_excel('./questionBank/otherSAS.xlsx')
    for i in range(len(df['questions'].values)):
        textList.append(df['questions'].values[i])

    global optionList
    optionList = [("1.无症状", 1),
                  ("2.轻", 2),
                  ("3.中等", 3),
                  ("4.重", 4),
                  ("5.极重", 5)]



    # Canvas,Scrollbar放置在主窗口上
    global canvas
    canvas = Canvas(master=selfSAS,width=880, height=800, bg='white')
    canvas.pack(anchor='center', pady=170)
    # 取消canvas边界
    canvas.config(highlightthickness=0)
    # 滚动条
    scro = Scrollbar(master=selfSAS)
    scro.pack(side='right',fill='y')

    # Frame作为容器放置组件
    frame = Frame(selfSAS, width=310, height=310, highlightbackground="black", highlightcolor="black",
                  highlightthickness=1, borderwidth=4, bg='white')
    frame.place(x=1500, y=10)

    # Frame作为容器放置组件
    frame1 = Frame(canvas, bg='white')
    frame1.pack()
    # 将Frame添加至Canvas上
    canvas.create_window((0,0),window=frame1, anchor="nw")
    # 添加内容，以grid布局
    i = 0


    global v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14

    i += 7
    # 第一个
    Label(frame1, text=textList[0], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v1 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v1, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第二个
    i += 1
    Label(frame1, text=textList[1], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v2 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v2, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第三个
    i += 1
    Label(frame1, text=textList[2], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v3 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v3, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第四个
    i += 1
    Label(frame1, text=textList[3], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v4 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v4, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1
    # 第五个
    i += 1
    Label(frame1, text=textList[4], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v5 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v5, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第六个
    i += 1
    Label(frame1, text=textList[5], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v6 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v6, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第七个
    i += 1
    Label(frame1, text=textList[6], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v7 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v7, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第八个
    i += 1
    Label(frame1, text=textList[7], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v8 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v8, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第九个
    i += 1
    Label(frame1, text=textList[8], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v9 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v9, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第十个
    i += 1
    Label(frame1, text=textList[9], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v10 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v10, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第十一个
    i += 1
    Label(frame1, text=textList[10], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v11 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v11, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第十二个
    i += 1
    Label(frame1, text=textList[11], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v12 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v12, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第十三个
    i += 1
    Label(frame1, text=textList[12], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v13 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v13, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1

    # 第十四个
    i += 1
    Label(frame1, text=textList[13], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    i += 1
    Label(frame1, text=textList[14], bg='whitesmoke').grid(row=i, columnspan=5, sticky=N+S+W+E)
    v14 = IntVar()
    i += 1
    j = 0
    for num, check in optionList:
        Radiobutton(frame1, text=num, variable=v14, value=check, bg='white',command = click).grid(row=i, column=j, sticky=W, ipadx=50, ipady=10)
        j += 1


    # 更新Frame大小，不然没有滚动效果
    frame1.update()
    # 将滚动按钮绑定只Canvas上
    canvas.configure(yscrollcommand=scro.set, scrollregion=canvas.bbox("all"))
    scro.config(command=canvas.yview)

    frame1.bind("<MouseWheel>",processWheel)
    canvas.bind("<MouseWheel>",processWheel)
    selfSAS.bind("<MouseWheel>",processWheel)
    click()
    mainloop()



    

